<#
PoshBot Service
#>

Import-Module PoshBot -Force

$myBotConfig = Get-PoshBotConfiguration -LiteralPath D:\PoshBotService\poshbot\config\PoshBot-config.psd1
$backend = New-PoshBotSlackBackend -Configuration $myBotConfig.BackendConfiguration

while($True) {
    try {
        $err = $null
        Start-PoshBot -Configuration $myBotConfig
        $bot = New-PoshBotInstance -Configuration $myBotConfig -Backend $backend
        $bot
        if($err) {
            throw $err
        }
    }
    catch {
        $_ | Format-List -Force | Out-String | Out-File (Join-Path $myBotConfig.LogDirectory Service.Error)
    }
}
