$nssm = 'D:\PoshBotService\service\nssm-2.24\win64\nssm.exe'
$ScriptPath = 'D:\PoshBotService\PoshBotService.ps1'
$ServiceName = 'poshService'
$ServicePath = 'C:\Program Files\PowerShell\6.0.2\pwsh.exe'
$ServiceArguments = '-ExecutionPolicy Bypass -File "{0}"' -f $ScriptPath
# -NoProfile
& $nssm install $ServiceName $ServicePath $ServiceArguments

# check the status... should be stopped
# start things up!
# verify it's running
& $nssm status $ServiceName
& $nssm start $ServiceName
& $nssm status $ServiceName

Get-Service -Name poshService | Set-Service -DisplayName "poshService" -Description "PoshBot - PowerShell Slack Bot. poshBot - Slack Bot for https://lukeleigh.slack.com. Used for running PowerShell tasks."
