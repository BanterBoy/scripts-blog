$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
(Invoke-WebRequest -Uri "https://www.bbc.co.uk/").StatusCode
