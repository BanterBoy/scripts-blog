if ($PSVersionTable.PSVersion.Major -ge 6) {

    Write-Output "Do something"

}
else {

    Write-Output "Do something else"

}
