Install-Module PSWriteHTML -Force -Scope CurrentUser
Install-Module PSWinReportingV2 -Force -Scope CurrentUser
Install-Module Dashimo -Force -Scope CurrentUser
Install-Module Documentimo -Force -Scope CurrentUser
Install-Module PSWinDocumentation.AD -Force -Scope CurrentUser
