function Show-PSDrive {
	Get-PSDrive | Format-Table -AutoSize
}