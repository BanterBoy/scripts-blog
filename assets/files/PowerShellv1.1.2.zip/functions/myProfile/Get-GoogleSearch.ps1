function Get-GoogleSearch {
    Start-Process "https://www.google.co.uk/search?q=$args"
}