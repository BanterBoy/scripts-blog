Update-Module -Name * -Force
Update-Help -Force
Write-Host "Update Completed!"
