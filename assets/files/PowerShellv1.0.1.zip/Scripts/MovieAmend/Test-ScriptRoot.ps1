function Test-ScriptRoot {
    $PSScriptRoot
}
