Event Logs to Email
Version 1, June 2018, James Pearman

This script takes the last Application and System events which are warnings or errors over the last 24 hours, puts them into a table in the body of the an email which is sent to an address you specify!

Change the parameters to what you need.
